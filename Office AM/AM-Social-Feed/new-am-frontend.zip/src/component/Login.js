import React, { useState, useEffect } from "react";
import { TextField, Button, Checkbox } from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";
function Login() {
  const navigate = useNavigate();
  const [type, setType] = useState("password");
  const [booleanValue, setBooleanValue] = useState(true);
  const [flag, setFlag] = useState(false);
  // const [emailid, setEmailId] = useState("");
  const [emailErrorMessage, setEmailErrorMessage] = useState("");
  const [passErrorMessage, setPassErrorMessage] = useState("");
  // const [password, setPassword] = useState("");
  const [authValue, setAuthValue] = useState(localStorage.getItem("authkey"));
  useEffect(() => {
    if (authValue !== null) navigate("/");
    if (authValue === null) navigate("/login");
  }, [authValue]);
  const [obj, setObj] = useState({
    email: "",
    password: "",
  });
  const changeTypeAndText = () => {
    setBooleanValue(!booleanValue);
    // console.log(booleanValue);
    if (booleanValue === true) setType("text");
    else setType("password");
  };

  const login = () => {
    setFlag(true);
    console.log(obj);
    axios.post("http://localhost:3300/api/user/login", obj).then((resp) => {
      console.log(resp);
      localStorage.setItem("authkey", resp.data.token);
      localStorage.setItem("myobj", JSON.stringify(obj));
      localStorage.setItem("name", resp.data.name);
      navigate("/", { state: resp.data });
      console.log(resp);
    }).catch = (err) => {
      console.log(err);
    };
  };

  useEffect(() => {
    // console.log("first");
    obj.email === "" && flag === true
      ? setEmailErrorMessage("Email Address is Required!!")
      : /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(obj.email) ===
          false && flag === true
      ? setEmailErrorMessage("enter valid email address")
      : setEmailErrorMessage("");
  }, [flag, obj.email]);

  useEffect(() => {
    obj.password === "" && flag === true
      ? setPassErrorMessage("password required")
      : obj.password.length <= 6 && flag === true
      ? setPassErrorMessage("password length must be greater than 6")
      : setPassErrorMessage("");
  }, [flag, obj.password]);

  return (
    <div className="App">
      <h2 className="App">Login</h2>
      <div className="emailAndPass">
        <div>
          <div>
            {" "}
            <label>Email: </label>
            <br />
            <br />
          </div>
          <TextField
            style={{ width: "30%" }}
            required
            id="outlined-required"
            label="Enter Username"
            helperText={emailErrorMessage}
            onChange={(e) => setObj({ ...obj, email: e.target.value })}
            error={
              /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(
                obj.email
              ) === true
                ? false
                : true && flag
            }
          />
        </div>
        <br />
        <br />
        <div>
          <label>Password: </label>
          <br />
          <br />
          <div>
            <TextField
              type={type}
              style={{ width: "30%" }}
              required
              id="outlined-required"
              label="Enter Password"
              helperText={passErrorMessage}
              onChange={(e) => setObj({ ...obj, password: e.target.value })}
              error={obj.password.length <= 6 && flag === true ? true : false}
            />
          </div>
          {/* <input type="checkbox" /> */}
          <Checkbox onChange={() => changeTypeAndText()} />

          {booleanValue === true ? "Show Password" : "Hide Password"}
        </div>
        <br />
        <br />
        <Button variant="contained" onClick={() => login()} disableElevation>
          Login
        </Button>{" "}
        OR{" "}
        <Button
          onClick={() => navigate("/sign-up")}
          variant="contained"
          disableElevation
        >
          Sign Up
        </Button>
      </div>
    </div>
  );
}

export default Login;
