import React, { useState } from "react";
import { TextField } from "@mui/material";
import { Button } from "@mui/material";
import { Checkbox } from "@mui/material";
import axios from "axios";
function ChangePassword() {
  const [type, setType] = useState("password");
  const [booleanValue, setBooleanValue] = useState(true);
  const [authValue1, setAuthValue1] = useState(localStorage.getItem("authkey"));
  const [newPass, setNewpass] = useState("");
  const changeTypeAndText = () => {
    setBooleanValue(!booleanValue);
    // console.log(booleanValue);
    if (booleanValue === true) setType("text");
    else setType("password");
  };

  const [obj1, setObj1] = useState({
    currentPassword: "",
    newPassword: "",
  });

  const changePassword = () => {
    if (newPass === obj1.newPassword) {
      axios
        .put("http://localhost:3300/api/user/updatePassword", obj1, {
          headers: {
            authorization: authValue1,
          },
        })
        .then((resp) => {
          console.log(resp);
        }).catch = (err) => {
        console.log(err);
      };
    } else {
      alert("current Password and new Password should be same");
      return;
    }
  };
  return (
    <div style={{ textAlign: "center" }}>
      <label>Current Password: </label>
      <br />
      <TextField
        onChange={(e) => setObj1({ ...obj1, currentPassword: e.target.value })}
      />
      <br />
      <br />
      <label>New Password : </label>
      <br />
      <TextField onChange={(e) => setNewpass(e.target.value)} type={type} />
      <br />
      <Checkbox onChange={() => changeTypeAndText()} />
      {booleanValue === true ? "Show Password" : "Hide Password"}
      <br />
      <br />
      <label>Confirm Password : </label>
      <br />
      <TextField
        type="password"
        onChange={(e) => setObj1({ ...obj1, newPassword: e.target.value })}
        error={obj1.newPassword !== newPass ? true : false}
      />
      <br />
      <Button variant="contained" onClick={() => changePassword()}>
        Change Password
      </Button>{" "}
      <br />
    </div>
  );
}

export default ChangePassword;
