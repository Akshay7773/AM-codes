import React, { useState, useEffect } from "react";
import { TextField, Button } from "@mui/material";
import axios from "axios";
import { useNavigate } from "react-router-dom";
function SignUp() {
  const navigate = useNavigate();
  const [flag, setFlag] = useState(false);

  const [obj, setObj] = useState({
    firstname: "",
    lastname: "",
    email: "",
    password: "",
  });

  const [firstNameError, setFirstNameError] = useState("");
  const [lastNameError, setLastNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passError, setPassError] = useState("");

  const register = () => {
    setFlag(true);
    // console.log(obj);
    console.log("akshay");
    axios
      .post("http://localhost:3300/api/user/register", obj)
      .then((response) => navigate("/login"))
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    obj.firstname === "" && flag === true
      ? setFirstNameError("First Name required")
      : setFirstNameError("");
  }, [flag, obj.firstname]);

  useEffect(() => {
    obj.lastname === "" && flag === true
      ? setLastNameError("Last Name required")
      : setLastNameError("");
  }, [flag, obj.lastname]);

  useEffect(() => {
    obj.email === "" && flag === true
      ? setEmailError("Email Address is Required!!")
      : /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(obj.email) ===
          false && flag === true
      ? setEmailError("enter valid email address")
      : setEmailError("");
  }, [flag, obj.email]);

  useEffect(() => {
    obj.password === "" && flag === true
      ? setPassError("Password required")
      : /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/.test(
          obj.password
        ) === false && flag === true
      ? setPassError("Enter valid password")
      : setPassError("");
  }, [flag, obj.password]);
  const [authValue, setAuthValue] = useState(localStorage.getItem("authkey"));
  useEffect(() => {
    if (authValue !== null) navigate("/");
  }, [authValue]);
  return (
    <div className="App">
      <h1 className="App">Sign Up</h1>
      <div className="emailAndPass">
        <div>
          <div>
            <label>First Name: </label>
          </div>
          <br />
          <TextField
            style={{ width: "40%" }}
            required
            // id="outlined-required"
            label="First Name"
            helperText={firstNameError}
            error={firstNameError ? true : false}
            onChange={(e) => setObj({ ...obj, firstname: e.target.value })}
          />
        </div>
        <br />
        <br />
        <div>
          <div>
            <label>Last Name: </label>
          </div>
          <br />
          <TextField
            style={{ width: "40%" }}
            required
            // id="outlined-required"
            label="Last Name"
            helperText={lastNameError}
            error={lastNameError ? true : false}
            onChange={(e) => setObj({ ...obj, lastname: e.target.value })}
          />
        </div>
        <br />
        <br />
        <div>
          <div>
            <label>Email: </label>
          </div>
          <br />
          <TextField
            style={{ width: "40%" }}
            required
            // id="outlined-required"
            label="Email"
            onChange={(e) => setObj({ ...obj, email: e.target.value })}
            helperText={emailError}
            error={emailError ? true : false}
          />
        </div>
        <br />
        <br />
        <div>
          <div>
            <label>Password: </label>
          </div>
          <br />
          <TextField
            style={{ width: "40%" }}
            required
            // id="outlined-required"
            label="Password"
            onChange={(e) => setObj({ ...obj, password: e.target.value })}
            helperText={passError}
            error={passError ? true : false}
          />
        </div>
        <br />
        <Button onClick={() => register()} variant="contained" disableElevation>
          Register
        </Button>
      </div>
    </div>
  );
}

export default SignUp;
