import React, { useEffect, useState } from "react";
import { Card, Collapse, Modal, TextField } from "@mui/material";
import { CardActions } from "@mui/material";
import { CardContent } from "@mui/material";
import { CardMedia } from "@mui/material";
import { Button } from "@mui/material";
import { Typography } from "@mui/material";
// import { useLocation } from "react-router-dom";
import { AppBar } from "@mui/material";
import { Toolbar } from "@mui/material";
import { Box } from "@mui/system";
import { IconButton } from "@mui/material";
import { useNavigate } from "react-router-dom";

import MenuItem from "@mui/material/MenuItem";

import axios from "axios";
import Menu from "@mui/material/Menu";
import ChangePassword from "./ChangePassword";

function Posts() {
  const [click1, setClick1] = useState(false);
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [authValue, setAuthValue] = useState(localStorage.getItem("authkey"));
  const [cmntArray, setCmntArray] = useState([]);

  const [sampleLikeState, setSampleLikeState] = useState("");

  useEffect(() => {
    console.log(authValue);
    axios
      .get("http://localhost:3300/api/post/getPost?page=1&limit=3", {
        headers: {
          authorization: authValue,
        },
      })
      .then((resp) => setPosts(resp.data));
  }, [sampleLikeState]);

  useEffect(() => {
    if (typeof localStorage.getItem("authkey") === "object") navigate("/login");
  }, []);

  // console.log(posts);
  const [obj, setObj] = useState({
    photo: "",
    caption: "",
  });
  // console.log(obj);
  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const uploaddata = () => {
    // console.log(obj);
    const formData = new FormData();
    formData.append("image", obj.photo);
    formData.append("caption", obj.caption);

    // console.log(formData.get("image"));
    axios
      .post("http://localhost:3300/api/post/addPost", formData, {
        headers: {
          authorization: authValue,
        },
      })
      .then((resp) => {
        axios
          .get("http://localhost:3300/api/post/getPost?page=1&limit=3", {
            headers: {
              authorization: authValue,
            },
          })
          .then((resp) => setPosts(resp.data));
        formData.delete("image");
        formData.delete("caption");
      }).catch = (err) => {
      console.log(err);
    };
  };

  // console.log(obj);
  const editProfile = () => {
    navigate("/Edit");
  };

  const commentClicked = (post) => {
    let arr = [];
    setClick1(!click1);
    posts.filter((p) =>
      p._id === post._id
        ? arr.push({ ...p, isclicked: !click1 })
        : arr.push({ ...p, isclicked: false })
    );
    setPosts(arr);
    console.log(post);
    axios
      .get(`http://localhost:3300/api/post/getComment/${post._id}`, {
        headers: {
          authorization: authValue,
        },
      })
      .then((resp) => setCmntArray(resp.data));
  };
  console.log(cmntArray);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const [open1, setOpen1] = React.useState(false);
  const handleOpen1 = () => setOpen1(true);
  const handleClose1 = () => setOpen1(false);

  const [type, setType] = useState("password");
  const [booleanValue, setBooleanValue] = useState(true);
  const [authValue1, setAuthValue1] = useState(localStorage.getItem("authkey"));
  const [newPass, setNewpass] = useState("");
  const [likesCount, setLikesCount] = useState(0);

  // const changeTypeAndText = () => {
  //   setBooleanValue(!booleanValue);
  //   // console.log(booleanValue);
  //   if (booleanValue === true) setType("text");
  //   else setType("password");
  // };

  const [obj1, setObj1] = useState({
    currentPassword: "",
    newPassword: "",
  });

  const changePassword = () => {
    if (newPass === obj1.newPassword) {
      axios
        .put("http://localhost:3300/api/user/updatePassword", obj1, {
          headers: {
            authorization: authValue1,
          },
        })
        .then((resp) => {
          console.log(resp);
        }).catch = (err) => {
        console.log(err);
      };
    } else {
      alert("current Password and new Password should be same");
      return;
    }
  };
  console.log(cmntArray);
  const likePost = (post) => {
    setSampleLikeState("");
    console.log(post._id);
    axios
      .put(
        "http://localhost:3300/api/post/likeToPost",
        { postId: post._id },
        {
          headers: {
            authorization: authValue,
          },
        }
      )
      .then((resp) => setSampleLikeState(post._id));
  };
  return (
    <div className="App">
      {" "}
      <h1>Posts</h1>
      <div>
        <div className="navbar">
          <Button style={{ marginRight: "200px", color: "white" }}>
            {localStorage.getItem("name")}
          </Button>
          <Button
            id="demo-positioned-button"
            aria-controls={open ? "demo-positioned-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
            onClick={handleClick}
          >
            Dashboard
          </Button>

          <Menu
            id="demo-positioned-menu"
            aria-labelledby="demo-positioned-button"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "top",
              horizontal: "left",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "left",
            }}
          >
            <MenuItem onClick={() => editProfile()}>Edit Profile</MenuItem>
            <MenuItem onClick={handleOpen1}>Change Password</MenuItem>
            <Modal
              open={open1}
              onClose={handleClose1}
              aria-labelledby="modal-modal-title"
              aria-describedby="modal-modal-description"
            >
              <Box className="box">
                <Typography id="modal-modal-title" variant="h6" component="h2">
                  current password:{" "}
                  <TextField
                    size="small"
                    type="password"
                    onChange={(e) =>
                      setObj1({ ...obj1, currentPassword: e.target.value })
                    }
                  />
                </Typography>
                <Typography id="modal-modal-title" variant="h6" component="h2">
                  new password:{" "}
                  <TextField
                    size="small"
                    style={{ padding: "6px" }}
                    onChange={(e) => setNewpass(e.target.value)}
                    type={type}
                  />
                </Typography>
                <Typography id="modal-modal-title" variant="h6" component="h2">
                  Confirm password:{" "}
                  <TextField
                    size="small"
                    type="password"
                    onChange={(e) =>
                      setObj1({ ...obj1, newPassword: e.target.value })
                    }
                    error={obj1.newPassword !== newPass ? true : false}
                  />
                </Typography>
                <br />
                <Typography id="modal-modal-title" variant="h6" component="h2">
                  <Button
                    style={{ marginLeft: "190px" }}
                    variant="contained"
                    onClick={() => changePassword()}
                  >
                    Change Password
                  </Button>
                </Typography>
              </Box>
            </Modal>
            <MenuItem onClick={() => logout()}>Logout</MenuItem>
          </Menu>
        </div>
        <br />
        <br />
        <Card style={{ maxWidth: 345 }}>
          <label>Upload Image: </label>
          <input
            style={{ marginLeft: "60px" }}
            type="file"
            multiple
            accept="image/*"
            onChange={(e) => setObj({ ...obj, photo: e.target.files[0] })}
          />
          <br />
          <br />
          <label>Caption: </label>
          <br />
          <br />
          <textarea
            onChange={(e) => setObj({ ...obj, caption: e.target.value })}
            type="text"
            style={{ width: "250px", height: "70px" }}
          />
          <CardContent></CardContent>
          <CardActions>
            <Button size="small" onClick={() => uploaddata()}>
              Upload Post
            </Button>
            <Button size="small">Cancel</Button>
          </CardActions>
        </Card>
      </div>
      {posts &&
        posts.map((post) => (
          <Box>
            <Card
              sx={{
                maxWidth: 450,
                // maxHeight: 450,
                border: "2px solid skyblue",
                marginLeft: "550px",
              }}
            >
              <CardMedia
                component="img"
                image={post.image}
                alt="green iguana"
              />

              <CardContent>
                <Typography variant="body2" color="text.secondary">
                  caption: {post.caption}
                </Typography>
              </CardContent>
              <CardActions>
                <Button size="small" onClick={() => likePost(post)}>
                  Like {post.likes.length}
                </Button>
                <Button size="small" onClick={() => commentClicked(post)}>
                  Comment
                </Button>
              </CardActions>

              <Collapse in={post.isclicked}>
                <TextField />
                <Button size="small">Comment</Button>
                <div>
                  {cmntArray &&
                    cmntArray.map((comn) => {
                      return (
                        <div key={comn._id}>
                          <p style={{ fontWeight: "bold" }}>{comn.createdBy}</p>
                          <p>{comn.text}</p>
                        </div>
                      );
                    })}
                </div>
              </Collapse>

              <br />
              <br />
            </Card>
            <br />
          </Box>
        ))}
    </div>
  );
}

export default Posts;
