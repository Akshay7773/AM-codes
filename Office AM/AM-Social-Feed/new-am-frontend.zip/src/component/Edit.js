import * as React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { Button } from "@mui/material";
import { TextField } from "@mui/material";
import axios from "axios";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { DesktopDatePicker, LocalizationProvider } from "@mui/lab";
import MuiPhoneNumber from "material-ui-phone-number";

const Edit = () => {
  const formData = new FormData();

  const [authValue, setAuthValue] = useState(localStorage.getItem("authkey"));
  const [userDetails, setUserDetails] = useState({});
  useEffect(() => {
    axios
      .get("http://localhost:3300/api/profile/getProfile", {
        headers: {
          authorization: authValue,
        },
      })
      .then((resp) => {
        setUserDetails(resp.data);
      });
  }, []);

  console.log(userDetails);
  // const [obj, setObj] = useState({
  //   bio: "",
  //   gender: "",
  //   image: "",
  //   userName: "",
  //   dob: "",
  //   email: "",
  //   mobile: "",
  // });
  // console.log(type);
  const [imageUrl, setImageUrl] = useState("");
  const updateUser = () => {
    // console.log(obj);
    formData.append("bio", userDetails.bio);
    formData.append("gender", userDetails.gender);
    formData.append("image", userDetails.image);
    formData.append("userName", userDetails.userName);
    formData.append("dob", userDetails.dob);
    formData.append("email", userDetails.email);
    formData.append("mobile", userDetails.mobile);

    axios
      .put(" http://localhost:3300/api/profile/update", formData, {
        headers: {
          authorization: authValue,
        },
      })
      .then((resp) => {
        console.log(resp);
        formData.delete("bio");
        formData.delete("gender");
        formData.delete("image");
        formData.delete("userName");
        formData.delete("dob");
        formData.delete("email");
        formData.delete("mobile");
      }).catch = (err) => {
      console.log(err);
    };
  };

  console.log(imageUrl);
  // if (userDetails.image.name) console.log(userDetails.image.name);
  const changeimg = (e) => {
    setUserDetails({ ...userDetails, image: e.target.files[0] });
    setImageUrl(URL.createObjectURL(e.target.files[0]));
  };
  return (
    <div>
      <br />
      <br />
      {imageUrl === "" ? (
        <img
          style={{ height: "200px", width: "200px", marginLeft: "28%" }}
          src={"http://localhost:3300/assets/profile/" + userDetails.image}
        />
      ) : (
        <img
          style={{ height: "200px", width: "200px", marginLeft: "28%" }}
          src={imageUrl}
        />
      )}
      <div style={{ marginLeft: "400px" }} className="rightdiv">
        <label>Bio: </label>
        <br />
        <br />
        <TextField
          label="Bio"
          style={{ width: "30%" }}
          value={userDetails && userDetails.bio}
          onChange={(e) =>
            setUserDetails({ ...userDetails, bio: e.target.value })
          }
        />
        <br />
        <br />
        <label>Gender: </label>
        <br />
        <TextField
          value={userDetails && userDetails.gender}
          style={{ width: "30%" }}
          onChange={(e) =>
            setUserDetails({ ...userDetails, gender: e.target.value })
          }
        />
        <br />
        <br />
        <label>Image: </label>
        <br />
        <input
          style={{ marginLeft: "60px" }}
          type="file"
          multiple
          accept="image/*"
          onChange={(e) => changeimg(e)}
        />
        <br />
        <br />
        <label>Username: </label>
        <br />
        <TextField
          value={userDetails && userDetails.userName}
          style={{ width: "30%" }}
          onChange={(e) =>
            setUserDetails({ ...userDetails, userName: e.target.value })
          }
        />
        <br />
        <br />
        <label>Date of Birth: </label>
        <br />
        {/* <TextField
          value={userDetails && userDetails.dob}
          style={{ width: "30%" }}
          onChange={(e) => setUserDetails({ ...obj, dob: e.target.value })}
        /> */}
        {console.log(userDetails.dob)}
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <DesktopDatePicker
            label="Date of Birth"
            value={new Date(userDetails.dob)}
            minDate={new Date("2017-01-01")}
            onChange={(newValue) => {
              console.log(newValue);
              setUserDetails({ ...userDetails, dob: newValue });
            }}
            renderInput={(params) => <TextField {...params} />}
          />
        </LocalizationProvider>
        <br />
        <br />
        <label>Email: </label>
        <br />
        <TextField
          value={userDetails && userDetails.email}
          style={{ width: "30%" }}
          onChange={(e) =>
            setUserDetails({ ...userDetails, email: e.target.value })
          }
        />
        <br />
        <br /> <label>Contact number: </label>
        <br />
        <TextField
          value={userDetails && userDetails.mobile}
          style={{ width: "30%" }}
          onChange={(e) =>
            setUserDetails({ ...userDetails, mobile: e.target.value })
          }
        />
        {/* <MuiPhoneNumber
          name="phone"
          label="Phone Number"
          data-cy="user-phone"
          defaultCountry={"us"}
          // value={this.state.phone}
          // onChange={this.handlePhoneChange}
        /> */}
        <br />
        <br />
      </div>
      <Button
        onClick={() => updateUser()}
        style={{ marginLeft: "31%" }}
        variant="contained"
      >
        Update Profile
      </Button>
    </div>
  );
};
export default Edit;
