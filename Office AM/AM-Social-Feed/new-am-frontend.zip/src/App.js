// import logo from "./logo.svg";
import "./App.css";
import Login from "./component/Login";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import SignUp from "./component/SignUp";
import Posts from "./component/Posts";
import Edit from "./component/Edit";
import ChangePassword from "./component/ChangePassword";
function App() {
  return (
    <div>
      <h1 className="App">Social Feed</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/sign-up" element={<SignUp />} />
          <Route path="/" element={<Posts />} />
          <Route path="/Edit" element={<Edit />} />
          {/* <Route path="changePassword" element={<ChangePassword />} /> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
