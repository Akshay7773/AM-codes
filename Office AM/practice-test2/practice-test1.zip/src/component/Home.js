import React, { useState, useEffect } from "react";
import axios from "axios";
import { Pagination } from "@material-ui/lab";
// import { useNavigate } from "react-router-dom";
function Home() {
  const data = JSON.parse(localStorage.getItem("mydata"));
  const [alldata, setAllData] = useState(data && data.length ? data : []);
  const [data1, setData1] = useState([]);
  console.log(data);
  console.log(alldata);
  //   const navigate = useNavigate();
  const [datas, setDatas] = useState([]);
  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [currPage, setCurrPage] = useState(0);
  const [data2, setData2] = useState([]);
  let data23 = datas;

  useEffect(() => {
    axios
      .get("http://interviewapi.ngminds.com/api/getAllProducts")
      .then((response) => setDatas(response.data.products));
  }, []);
  console.log(datas);
  const incCartValue = (data, id) => {
    setAllData([...alldata, { data }]);
  };

  const hello = () => {
    localStorage.setItem("mydata", JSON.stringify(alldata));
    // navigate("/Home/Cart");
  };
  const changePage = (event) => {
    const pageNumber = Number(event.target.textContent);
    console.log(pageNumber);
    setCurrPage(pageNumber);
  };
  //   console.log(itemsPerPage);
  //   console.log(alldata);
  const sort = (e) => {
    let arr = [];
    if (e.target.value === "default") {
      axios
        .get("http://interviewapi.ngminds.com/api/getAllProducts")
        .then((response) => setDatas(response.data.products));
    }
    if (e.target.value === "Low to High") {
      for (let i = 0; i < datas.length; i++) {
        for (let j = i + 1; j < datas.length; j++) {
          if (parseInt(datas[i].price) > parseInt(datas[j].price)) {
            let temp = datas[i];
            datas[i] = datas[j];
            datas[j] = temp;
          }
        }
        arr.push(datas[i]);
      }
    } else {
      for (let i = 0; i < datas.length; i++) {
        for (let j = i + 1; j < datas.length; j++) {
          if (parseInt(datas[i].price) < parseInt(datas[j].price)) {
            let temp = datas[i];
            datas[i] = datas[j];
            datas[j] = temp;
          }
        }
        arr.push(datas[i]);
      }
    }
    setDatas(arr);
  };

  return (
    <div>
      <div className="container">
        <h1>
          <a href="/">My Ecommerce Site</a>
          <span class="pull-right">
            <a href="cart.html">Cart (0)</a>
          </span>
        </h1>
        <hr />
        <div class="row">
          <div class="col-sm-12">
            <div className="secondDiv">
              <label for="" class="control-label">
                Sort by:
              </label>
              <select onChange={(e) => sort(e)} name="" id="">
                <option value="default">Default</option>
                <option value="High to Low">High to Low</option>
                <option value="Low to High">Low to High</option>
              </select>
            </div>
          </div>
        </div>
        <hr />
        <div className="row">
          {datas &&
            datas &&
            datas.map((datas, i) => (
              <div className="col-md-3">
                <div
                  className={
                    i % 4 === 0
                      ? "bg-info"
                      : i % 4 !== 0 && i % 2 == 0
                      ? "bg-warning"
                      : i % 3 === 0 ||
                        (i % 3 === 1 && i % 4 !== 0 && i % 2 !== 0 && i !== 1)
                      ? "bg-danger"
                      : "bg-success"
                  }
                >
                  <img
                    src={`http://interviewapi.ngminds.com/${datas.image}`}
                    width="100"
                    height="200"
                  />
                  <br />
                  <br />
                  <p>{datas.name}</p>
                  <p>
                    <i className="fa fa-inr"></i>
                    {datas.price}
                  </p>
                  <a
                    className="btn btn-warning"
                    onClick={() => incCartValue(datas, datas._id)}
                  >
                    Add to Cart
                  </a>
                </div>
                <br></br>
                <br></br>
                <hr style={{ backgroundColor: "#000" }} />
              </div>
            ))}
        </div>
      </div>
      <div class="row">
        <div class="col-sm-8">
          <Pagination
            className="pagination"
            // activePage={this.state.activePage}
            itemsCountPerPage={10}
            totalItemsCount={450}
            data={datas}
            count={itemsPerPage}
            onChange={(event) => changePage(event)}
            // pageLimit={5}
          />
        </div>
        <div class="col-sm-4 text-right">
          <div className="lastDiv">
            <label for="" class="control-label">
              Items Per Page:
            </label>
            <select
              onChange={(e) => setItemsPerPage(e.target.value)}
              name=""
              id=""
            >
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="25">25</option>
              <option value="50">50</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
